﻿using System.ComponentModel.DataAnnotations;

namespace ToDoList.Models
{
    public class ToDoViewModel
    {
        public List<ToDo> Tasks { get; set; } = new();
        public List<Category> Categories { get; set; } = new();
        public List<Status> Statuses { get; set; } = new();

        public List<string> DueDates { get; set; } = new() { "Past", "Today", "Future" };

        [Required(ErrorMessage = "Please enter a description.")]
        public string? CurrentTask { get; set; }

        [Required(ErrorMessage = "Please select a category.")]
        public string? SelectedCategory { get; set; }

        [Required(ErrorMessage = "Please select a status.")]
        public string? SelectedStatus { get; set; }

        [Required(ErrorMessage = "Please select a due date.")]
        public string? SelectedDueDate { get; set; }

        public string? Action { get; set; }
    }
}