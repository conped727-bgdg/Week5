﻿namespace ToDoList.Models
{
    public class Filters
    {
        public Filters(string filterstring)
        {
            FilterString = filterstring ?? "all-all-all";
            string[] filters = FilterString.Split('-');
            CategoryId = filters[0];
            Due = filters[1];
            StatusId = filters[2];
        }

        public string FilterString { get; }
        public string CategoryId { get; }
        public string Due { get; }
        public string StatusId { get; }

        public bool HasCategory => CategoryId != "all";
        public bool HasDue => Due != "all";
        public bool HasStatus => StatusId != "all";

        public bool IsPast => Due == "Past";
        public bool IsToday => Due == "Today";
        public bool IsFuture => Due == "Future";
    }
}