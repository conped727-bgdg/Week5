﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToDoList.Models;

namespace ToDoList.Controllers
{
    public class HomeController : Controller
    {
        private ToDoContext context;
        public HomeController(ToDoContext ctx) => context = ctx;

        public ViewResult Index(string id)
        {
            var filters = new Filters(id);

            var model = new ToDoViewModel
            {
                Categories = context.Categories.ToList(),
                Statuses = context.Statuses.ToList(),
                DueDates = new List<string> { "Past", "Today", "Future" },
                SelectedCategory = filters.CategoryId,
                SelectedStatus = filters.StatusId,
                SelectedDueDate = filters.Due,
                Action = filters.FilterString
            };

            IQueryable<ToDo> query = context.ToDos
                .Include(t => t.Category)
                .Include(t => t.Status);

            if (filters.HasCategory)
                query = query.Where(t => t.CategoryId == filters.CategoryId);

            if (filters.HasStatus)
                query = query.Where(t => t.StatusId == filters.StatusId);

            if (filters.HasDue)
            {
                if (filters.IsPast)
                    query = query.Where(t => t.DueDate == "Past");
                else if (filters.IsToday)
                    query = query.Where(t => t.DueDate == "Today");
                else if (filters.IsFuture)
                    query = query.Where(t => t.DueDate == "Future");
            }

            model.Tasks = query.ToList();

            return View(model);
        }

        [HttpGet]
        public ViewResult Add()
        {
            var model = new ToDoViewModel
            {
                Categories = context.Categories.ToList(),
                Statuses = context.Statuses.ToList(),
                DueDates = new List<string> { "Past", "Today", "Future" },
                SelectedStatus = "open"
            };

            return View(model);
        }

        [HttpPost]
        public IActionResult Add(ToDoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                model.Categories = context.Categories.ToList();
                model.Statuses = context.Statuses.ToList();
                model.DueDates = new List<string> { "Past", "Today", "Future" };
                return View(model);
            }

            var task = new ToDo
            {
                Description = model.CurrentTask!,
                CategoryId = model.SelectedCategory!,
                StatusId = model.SelectedStatus!,
                DueDate = model.SelectedDueDate!
            };

            context.ToDos.Add(task);
            context.SaveChanges();

            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Filter(string[] filter)
        {
            string id = string.Join('-', filter);
            return RedirectToAction("Index", new { ID = id });
        }

        [HttpPost]
        public IActionResult MarkComplete([FromRoute] string id, ToDo selected)
        {
            selected = context.ToDos.Find(selected.Id)!;
            if (selected != null)
            {
                selected.StatusId = "closed";
                context.SaveChanges();
            }

            return RedirectToAction("Index", new { ID = id });
        }

        [HttpPost]
        public IActionResult DeleteComplete(string id)
        {
            var toDelete = context.ToDos
                .Where(t => t.StatusId == "closed").ToList();

            foreach (var task in toDelete)
            {
                context.ToDos.Remove(task);
            }
            context.SaveChanges();

            return RedirectToAction("Index", new { ID = id });
        }
    }
}