﻿using Microsoft.AspNetCore.Mvc;
using TempManager.Models;
using System.Linq;

namespace TempManager.Controllers
{
    public class HomeController : Controller
    {
        private TempManagerContext data { get; set; }
        public HomeController(TempManagerContext ctx) => data = ctx;

        public ViewResult Index()
        {
            var temps = data.Temps.OrderBy(t => t.Date).ToList();
            return View(temps);
        }

        [HttpGet]
        public ViewResult Add() => View(new Temp());

        [HttpPost]
        public IActionResult Add(Temp temp)
        {
            // Server-side duplicate date check
            if (data.Temps.Any(t => t.Date == temp.Date))
            {
                ModelState.AddModelError("Date", "That date already exists.");
            }

            if (ModelState.IsValid)
            {
                data.Temps.Add(temp);
                data.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                // Model-level validation message
                ModelState.AddModelError("", "Please correct all errors.");
                return View(temp);
            }
        }

        // Remote validation method
        [AcceptVerbs("Get", "Post")]
        public IActionResult CheckDuplicateDate(DateTime date)
        {
            bool exists = data.Temps.Any(t => t.Date == date);

            if (exists)
                return Json($"The date {date.ToShortDateString()} already exists.");
            else
                return Json(true);
        }

        [HttpGet]
        public ViewResult Delete(int id)
        {
            var temp = data.Temps.Find(id);
            return View(temp);
        }

        [HttpPost]
        public RedirectToActionResult Delete(Temp temp)
        {
            data.Remove(temp);
            data.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}